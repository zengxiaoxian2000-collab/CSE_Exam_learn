﻿# 1. Get today's date
$Today = Get-Date -Format "yyyy-MM-dd"

# 2. Print banner
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "   注安 AI 教练 - 自动唤醒程序" -ForegroundColor Cyan
Write-Host "   当前系统日期: $Today" -ForegroundColor Yellow
Write-Host "=========================================" -ForegroundColor Cyan

# 3. Wait for user confirmation
Read-Host "请确认已准备好纸笔，按下 [回车键] 唤醒教练并抽取今日错题..."

# 4. Build the prompt with today's date
$Prompt = "今天是 $Today，请首先读取 /04_错题与复习数据库/ebbinghaus_db.json 文件。1. 比对里面的 next_review 日期，如果等于或早于今天，请立刻把该错题提问给我。2. 如果我答对了，更新该题的 review_stage，并计算下一个周期的复习日期写入 JSON。3. 如果我答错了，把该题的复习周期重置为 0，并将下次复习日期设为明天。4. 所有到期错题复习完毕后，告诉我结果，我们再开始今天新章节的学习。"

# 5. Send the instruction to Claude Code
claude $Prompt
